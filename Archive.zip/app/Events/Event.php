<?php

namespace F1donky\Events;

abstract class Event
{
    //
}
