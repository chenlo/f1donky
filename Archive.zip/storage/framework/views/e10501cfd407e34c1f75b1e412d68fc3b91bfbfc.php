<?php $__env->startSection('header'); ?>
     <div class="panel-heading main-title">
        <h1>Grandes Premios</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
    <div class="container">
        <?php foreach($races as $race): ?>
        <div class="row panel <?php echo e($race->isNext() ? '' : 'actual'); ?>">
            <div class="col-md-2 col-xs-4 center-block flag">
                <?php echo Html::image('assets/img/races/'.$race->id.'.jpg'); ?>

            </div>      
            <div class="col-md-10 col-xs-8">
                <h4>
                    <?php echo e($race->mainName()); ?> 
                </h4>
                <p class="small">
                    <?php echo e($race->start); ?>

                    <?php if($race->isStarted()): ?>
                        <i class="glyphicon glyphicon-ok tick"></i>    
                    <?php endif; ?>
                </p>
                <p>
                <ul class="list-inline">
                    <?php if($race->hasResults()): ?>
                        <li><a href="<?php echo e(route('races.show', $race->id)); ?>" class="btn btn-success">Ver puntuaciones</a></p></li>
                    <?php endif; ?>
                    <?php if( Auth::check() && Auth::user()->isAdmin() ): ?>
                        <li><a href="<?php echo e(route('races.edit', $race->id)); ?>" class="btn btn-success">Editar</a></p></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>