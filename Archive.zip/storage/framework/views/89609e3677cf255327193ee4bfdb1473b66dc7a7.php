<?php $__env->startSection('header'); ?>
     <div class="panel-heading main-title">
        <h1>Clasificación general de F1 Donky <?php echo date("Y"); ?></h1>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
    <div class="container">
        <table class="table table-striped">
            <tr>
                <th>#</th>
                <th>Usuario</th>
                <th>Puntos</th>
            </tr>
            <?php foreach($users as $index => $user): ?>
                <tr>
                    <td>
                        <?php echo e($index+1); ?>

                    </td>
                    <td>
                        <?php echo e($user->getName()); ?>

                    </td>
                    <td>
                        <?php echo e($user->getTotalScore()); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>