<?php $__env->startSection('header'); ?>
     <div class="panel-heading main-title">
     	<div class="container">
     		<div class="row">
     			<div class="col-sm-1 col-xs-12 block-center center-block">
     				<?php echo Html::image('assets/img/races/'.$race->id.'.jpg', null, array('class' => 'thumb-flag center-block')); ?>

     			</div>
     			<div class="col-sm-11 col-xs-12 text-center">
     				<h1><?php echo e($race->mainName()); ?></h1>
					<h4><?php echo e($race->start); ?></h4>
     			</div>
     		</div>
     	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel-body">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-9">
    				<?php echo Form::model($race, [
    					'method' => 'PATCH',
    					'route' => ['races.update', $race->id]
					]); ?>	
		        	<div class="form-group">
				     	<?php echo Form::label('p1', 'Primero'); ?>

				     	<div class="form-controls">
				       	<?php echo Form::select('p1', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

				    	</div>
				   	</div>
				   	<div class="form-group">
				     	<?php echo Form::label('p2', 'Segundo'); ?>

				     	<div class="form-controls">
				       	<?php echo Form::select('p2', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

				    	</div>
				   	</div>
				   	<div class="form-group">
				     	<?php echo Form::label('p3', 'Tercero'); ?>

				     	<div class="form-controls">
				       	<?php echo Form::select('p3', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

				    	</div>
				   	</div>
				   	<div class="form-group">
				     	<?php echo Form::label('p4', 'Cuarto'); ?>

				     	<div class="form-controls">
				       	<?php echo Form::select('p4', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

				    	</div>
				   	</div>
				   	<div class="form-group">
				     	<?php echo Form::label('p5', 'Quinto'); ?>

				     	<div class="form-controls">
				       	<?php echo Form::select('p5', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

				    	</div>
				   	</div>
				   	<div class="form-group">
				     	<?php echo Form::label('pole', 'Pole position'); ?>

				     	<div class="form-controls">
				       	<?php echo Form::select('pole', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

				    	</div>
				   	</div>
				   	<div class="form-group">
				     	<?php echo Form::label('fastest', 'Vuelta rápida'); ?>

				     	<div class="form-controls">
				       	<?php echo Form::select('fastest', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

				    	</div>
				   	</div>
		            <?php echo Form::submit('Actualizar', ['class' => 'btn btn-primary']); ?>

		        <?php echo Form::close(); ?>

    			</div>
    			<div class="col-sm-3">
    				<?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    			</div>
    		</div>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php
/*
{!! Form::model($race, ['url' => '/races/'.$race->id], 'method' => 'put') !!}
*/
?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>