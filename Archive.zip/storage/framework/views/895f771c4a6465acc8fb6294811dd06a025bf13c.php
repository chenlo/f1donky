<?php $__env->startSection('header'); ?>
     <div class="panel-heading main-title">
        <h1>Pilotos</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
    <div class="container">
        <ul class="list-group">
        <?php foreach($drivers as $driver): ?>
            <li class="list-group-item"><?php echo e($driver->getLastName()); ?> - <?php echo e($driver->getTeamName()); ?></li>
        <?php endforeach; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>