<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
</head>
<body>
	<h1><?php echo e($bet_info["race"]); ?></h1>
	<p>
		<ul>
			<li>Primero: <?php echo e($bet_info["p1"]); ?></li>
			<li>Segundo: <?php echo e($bet_info["p2"]); ?></li>
			<li>Tercero: <?php echo e($bet_info["p3"]); ?></li>
			<li>Cuarto: <?php echo e($bet_info["p4"]); ?></li>
			<li>Quinto: <?php echo e($bet_info["p5"]); ?></li>
		</ul>
	</p>
	<p>Pole: <?php echo e($bet_info["pole"]); ?></p>
	<p>Vuelta rápida: <?php echo e($bet_info["fastest"]); ?></p>
</body>
</html>
