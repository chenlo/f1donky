<?php $__env->startSection('header'); ?>
     <div class="panel-heading main-title">
        <div class="container">
            <div class="row">
                <div class="col-sm-1 col-xs-12 block-center flag text-center">
                    <?php echo Html::image('assets/img/races/'.$race->id.'.jpg'); ?>

                </div>
                <div class="col-sm-11 col-xs-12 text-center">
                    <h1><?php echo e($race->mainName()); ?></h1>
                    <h4><?php echo e($race->start); ?></h4>
                    <nav class="row">
                        <div class="col-xs-6">
                            <?php if(!$race->isFirstRaceOfSeason()): ?>
                            <a href="<?php echo e(route('races.show', $race->id-1)); ?>">
                                <i class="glyphicon glyphicon-arrow-left"></i>    
                            </a>
                            <?php endif; ?>        
                        </div>
                        <div class="col-xs-6">
                            <?php if($race->hasNextResults()): ?>
                            <a href="<?php echo e(route('races.show', $race->id+1)); ?>">
                                <i class="glyphicon glyphicon-arrow-right"></i>    
                            </a>
                            <?php endif; ?>
                        </div>
                    </nav>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Puntuaciones</h2>
        <div class="table-responsive">
            <table class="table table-striped">
                <tr>
                    <th>Usuario</th>
                    <th>Total</th>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                    <th>Pole</th>
                    <th>Fastest</th>
                    <th>Cinco</th>
                    <th>Bonus</th>
                </tr>
                <?php foreach($bets as $bet): ?>
                    <tr>
                        <td>
                            <?php echo e($bet->user->name); ?>

                        </td>
                        <td>
                            <?php echo e($bet->getTotalScore()); ?>

                        </td>
                        <td class="<?php echo e($bet->hasGuessedP1() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP1()); ?>

                        </td>
                        <td class="<?php echo e($bet->hasGuessedP2() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP2()); ?>

                        </td>
                        <td class="<?php echo e($bet->hasGuessedP3() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP3()); ?>

                        </td>
                        <td class="<?php echo e($bet->hasGuessedP4() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP4()); ?>

                        </td>
                        <td class="<?php echo e($bet->hasGuessedP5() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP5()); ?>

                        </td>
                        <td class="<?php echo e($bet->hasGuessedPole() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNamePole()); ?>

                        </td>
                        <td class="<?php echo e($bet->hasGuessedFastest() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameFastest()); ?>

                        </td>
                        <td class="text-center">
                            <?php if($bet->hasFivePilotsUnordered()): ?>
                                <i class="glyphicon glyphicon-ok tick green"></i> 
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if($bet->hasBonus()): ?>
                                <i class="glyphicon glyphicon-king"></i> 
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <div class="panel panel-default panel-scores">
            <ul class="list-inline text-primary">
                <li>P1=25 puntos</li>
                <li>P2=18 puntos</li>
                <li>P3=15 puntos</li>
                <li>P4=12 puntos</li>
                <li>P5=10 puntos</li>
                <li>Pole=10 puntos</li>
                <li>Fastest=10 puntos</li>
                <li>Cinco=10 puntos</li>
                <li>Bonus=50 puntos</li>
            </ul>
        </div>
        <h2>Resultados de la carrera</h2>
        <table class="table table-striped">
            <tr>
                <th>#</th>
                <th>Piloto</th>
            </tr>
            <tr>
                <td>Primero</td>
                <td><?php echo e($race->getNameP1()); ?></td>
            </tr>
            <tr>
                <td>Segundo</td>
                <td><?php echo e($race->getNameP2()); ?></td>
            </tr>
            <tr>
                <td>Tercero</td>
                <td><?php echo e($race->getNameP3()); ?></td>
            </tr>
            <tr>
                <td>Cuarto</td>
                <td><?php echo e($race->getNameP4()); ?></td>
            </tr>
            <tr>
                <td>Quinto</td>
                <td><?php echo e($race->getNameP5()); ?></td>
            </tr>
            <tr>
                <td>Pole position</td>
                <td><?php echo e($race->getNamePole()); ?></td>
            </tr>
            <tr>
                <td>Vuelta rápida</td>
                <td><?php echo e($race->getNameFastest()); ?></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>