<?php $__env->startSection('header'); ?>
     <div class="panel-heading main-title">
     	<div class="container">
     		<div class="row">
                    <div class="col-sm-1 col-xs-12 block-center center-block">
                         <?php echo Html::image('assets/img/races/'.$race->id.'.jpg', null, array('class' => 'thumb-flag center-block')); ?>

                    </div>
     			<div class="col-sm-11 col-xs-12">
     				<h1><?php echo e($race->mainName()); ?></h1>
					<h4><?php echo e($race->start); ?> - <?php echo e($race->getDateDiffHumans()); ?></h4>
     			</div>
     		</div>
     	</div>
	</div>
     <div class="panel-body">
          <div class="container">
               <div class="row">
                    <div class="col-sm-9">
                         <?php echo Form::model($race, [
                              'method' => 'POST',
                              'route' => ['bets.store']
                         ]); ?>    
                         <input type="hidden" name="user_id" id="user_id" value="<?php echo e(Auth::user()->id); ?>">
                         <input type="hidden" name="race_id" id="race_id" value="<?php echo e($race->id); ?>">
                         <div class="form-group">
                                   <?php echo Form::label('p1', 'Primero'); ?>

                                   <div class="form-controls">
                                   <?php echo Form::select('p1', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

                              </div>
                              </div>
                              <div class="form-group">
                                   <?php echo Form::label('p2', 'Segundo'); ?>

                                   <div class="form-controls">
                                   <?php echo Form::select('p2', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

                              </div>
                              </div>
                              <div class="form-group">
                                   <?php echo Form::label('p3', 'Tercero'); ?>

                                   <div class="form-controls">
                                   <?php echo Form::select('p3', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

                              </div>
                              </div>
                              <div class="form-group">
                                   <?php echo Form::label('p4', 'Cuarto'); ?>

                                   <div class="form-controls">
                                   <?php echo Form::select('p4', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

                              </div>
                              </div>
                              <div class="form-group">
                                   <?php echo Form::label('p5', 'Quinto'); ?>

                                   <div class="form-controls">
                                   <?php echo Form::select('p5', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

                              </div>
                              </div>
                              <div class="form-group">
                                   <?php echo Form::label('pole', 'Pole position'); ?>

                                   <div class="form-controls">
                                   <?php echo Form::select('pole', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

                              </div>
                              </div>
                              <div class="form-group">
                                   <?php echo Form::label('fastest', 'Vuelta rápida'); ?>

                                   <div class="form-controls">
                                   <?php echo Form::select('fastest', $drivers, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar piloto']); ?>

                              </div>
                              </div>
                           <?php echo Form::submit('Votar', ['class' => 'btn btn-primary']); ?>

                       <?php echo Form::close(); ?>

                    </div>
                    <div class="col-sm-3">
                         <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
               </div>
          </div>
     </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>