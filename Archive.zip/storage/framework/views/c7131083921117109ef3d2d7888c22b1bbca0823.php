<?php $__env->startSection('header'); ?>
     <div class="panel-heading main-title">
        <h1><?php echo e(Auth::user()->getName()); ?>, llevas <?php echo e(Auth::user()->getTotalScore()); ?> puntos.</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
    <div class="container">
        <h2>Éstas han sido tus apuestas:</h2>
        <?php foreach($bets as $bet): ?>
        <div class="row panel">
            <div class="col-md-1 col-xs-3 center-block flag">
                <?php echo Html::image('assets/img/races/'.$bet->race->id.'.jpg', null, array('class' => 'thumb-flag center-block')); ?>

            </div>      
            <div class="col-md-11 col-xs-9">
                <h4>
                    <?php echo e($bet->race->mainName()); ?>

                </h4>
                <h5><?php echo e($bet->race->start); ?></h5>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="panel panel-success">
                        <div class="panel-body">Puntuación: <?php echo e($bet->getTotalScore()); ?></div>
                    </div>
                </div>
                <div class="col-md-3">
                    <ul class="list-group">
                        <li class="list-group-item <?php echo e($bet->hasGuessedP1() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP1()); ?><span class="badge">1</span>
                        </li>
                        <li class="list-group-item <?php echo e($bet->hasGuessedP2() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP2()); ?><span class="badge">2</span>
                        </li>
                        <li class="list-group-item <?php echo e($bet->hasGuessedP3() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP3()); ?><span class="badge">3</span>
                        </li>
                        <li class="list-group-item <?php echo e($bet->hasGuessedP4() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP4()); ?><span class="badge">4</span>
                        </li>
                        <li class="list-group-item <?php echo e($bet->hasGuessedP5() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameP5()); ?><span class="badge">5</span>
                        </li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <ul class="list-group">
                        <li class="list-group-item <?php echo e($bet->hasGuessedPole() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNamePole()); ?><span class="badge">pole</span>
                        </li>
                        <li class="list-group-item <?php echo e($bet->hasGuessedFastest() ? 'green' : ''); ?>">
                            <?php echo e($bet->getNameFastest()); ?><span class="badge">fast</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-9">
                    <div class="panel panel-success">
                        <div class="panel-body">
                            <?php if($bet->race->hasResults()): ?>
                                <a href="<?php echo e(route('races.show', $bet->race->id)); ?>">Ver todas las puntuaciones de la carrera.</a>
                            <?php else: ?>
                                <span class="label label-warning">Resultados de la carrera no disponibles.</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>